#define _GNU_SOURCE
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

#include "ipc.h"
#include "pa2.h"
#include "business.h"
#include "common.h"
#include "banking.h"

#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>



// parse command - form: ./pa2 -p X y1 y2 y3 ...
int parse_command(int argc, char *argv[])
{
    int proc_count; // counts of child processes
    if (strcmp(argv[1], "-p") && (proc_count = atoi(argv[2]) == (argc - 3)))
    {
        return proc_count;
    }
    return -1;
}

int recvmsg(IPC* ipc) {
    Message msg ;
    
    while(1) {
        receive_any(ipc, &msg);

        TransferOrder* t = (TransferOrder*)msg.s_payload;

        switch (msg.s_header.s_type) {
            case TRANSFER : {
                set_new_balance(&ipc->balance_history,
                                t->s_amount,
                                msg.s_header.s_local_time + 1 );

                if(t -> s_amount > 0) {
                    transfer_time(ipc, t->s_dst,
                                  ipc->worker_id,
                                  -(t->s_amount), 
                                  msg.s_header.s_local_time );
                }
                continue;
            }
            case STOP : {
                return 0;
            }
        } 
        
    }
}

int work(IPC* ipc) {
    close_unused_pipes(ipc);
    fprintf(ipc->event_log, log_started_fmt,get_physical_time(), ipc->worker_id,getpid(),getppid(), ipc->balance_history.s_history[ipc->balance_history.s_history_len].s_balance);

    sendmsg(ipc);
    fprintf(ipc->event_log, log_received_all_started_fmt, get_physical_time(), ipc->worker_id);
    recvmsg(ipc);
    fprintf(ipc->event_log, log_done_fmt, get_physical_time(), ipc->worker_id, ipc->balance_history.s_history[ipc->balance_history.s_history_len].s_balance);

    send_history(ipc);
    fprintf(ipc -> event_log, log_received_all_done_fmt, get_physical_time(),ipc -> worker_id);
    

    return 0;
}

int main(int argc, char* argv[]){
    IPC* ipc = calloc(1, sizeof(IPC));
    int process_count = parse_command(argc,argv);
    ipc -> num_workers = process_count;
    AllHistory history = {.s_history_len = process_count};

    for(int i = 0; i < process_count; i++) {
        BalanceHistory h = {.s_id = i+1,
                            .s_history_len = process_count + 1 };
        for(int j = 0; j < process_count + 1; j++)
        {
            BalanceState state = {.s_balance = atoi(argv[i + 3]),
                                   .s_time = j};
            h.s_history[j] = state;
        }
        history.s_history[i] = h;
    }

    init_pipes(ipc);
    init_logs(ipc);

    for(int i = 0; i < process_count; i++) {
        int pid = fork();
        if(pid == 0){
            ipc -> worker_id = i + 1;
            ipc -> balance_history = history.s_history[i];
            work(ipc);
            history.s_history[i] = ipc -> balance_history;
            exit(0);
        }
    }
    ipc -> worker_id = 0;
    close_unused_pipes(ipc);
    bank_robbery(ipc, process_count);
    send_stop(ipc);
    get_balances(ipc, &history);
    for(int i = 0; i < process_count; i++) {
        wait(NULL);
    }
    print_history(&history);

    return 0;
}
