int get_proc_count(int argc, char** argv);
balance_t get_proc_balance(local_id proc_id, char** argv);

int parent_work(PipesCommunication* comm);
int dotasks(PipesCommunication* comm);

int dotransfer(PipesCommunication* comm, Message* msg, BalanceState* state, BalanceHistory* history);
void old_update(BalanceState* state, BalanceHistory* history, balance_t amount, timestamp_t timestamp_msg, char inc, char fix);
