#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include "process.h"

int parent_work(PipesCommunication* comm){
	AllHistory all_history;
	local_id i;
	
	all_history.s_history_len = comm->total_ids - 1;
	
    receive_all_msgs(comm, STARTED);

    /* Payload */
    bank_robbery(comm, comm->total_ids - 1);

	/* Payload ended, stop children work */
	increment_lamport_time();
    send_all_stop_msg(comm);
    receive_all_msgs(comm, DONE);
	
	/* Fill in History */
	for (i = 1; i < comm->total_ids; i++){
		BalanceHistory balance_history;
		Message msg;
		
		while(receive(comm, i, &msg));
		
		if (msg.s_header.s_type != BALANCE_HISTORY){
			return -1;
		}
		
		memcpy((void*)&balance_history, msg.s_payload, sizeof(char) * msg.s_header.s_payload_len);
		all_history.s_history[i - 1] = balance_history;
	}
	
	print_history(&all_history);
	return 0;
}

int dotasks(PipesCommunication* comm){
	BalanceState balance_state;
    BalanceHistory balance_history;
	size_t done_left = comm->total_ids - 2;
	int not_stopped = 1;

    balance_history.s_id = comm->current_id;
	
	balance_state.s_balance = comm->balance;
    balance_state.s_balance_pending_in = 0;
    balance_state.s_time = 0;
	
	old_update(&balance_state, &balance_history, 0, 0, 0, 0);
	
	/* Send & receive STARTED message */
	increment_lamport_time();
	send_all_proc_event_msg(comm, STARTED);
	increment_lamport_time();
    receive_all_msgs(comm, STARTED);
	
	/* Receive TRANSFER, STOP or DONE messages */
	while(done_left || not_stopped){
		Message msg;
		
        while (receive_any(comm, &msg));
		
		if (msg.s_header.s_type == TRANSFER){
			dotransfer(comm, &msg, &balance_state, &balance_history);
		}
		else if (msg.s_header.s_type == STOP){
			old_update(&balance_state, &balance_history, 0, msg.s_header.s_local_time, 1, 0);
			send_all_proc_event_msg(comm, DONE);
			not_stopped = 0;
		}
		else if (msg.s_header.s_type == DONE){
			old_update(&balance_state, &balance_history, 0, msg.s_header.s_local_time, 1, 0);
			done_left--;
		}
		else{
			return -1;
		}
	}
	
	log_received_all_done(comm->current_id);
	
	/* Update history and send to PARENT */
	old_update(&balance_state, &balance_history, 0, 0, 1, 0);
	send_balance_history(comm, PARENT_ID, &balance_history);
	return 0;
}

int dotransfer(PipesCommunication* comm, Message* msg, BalanceState* state, BalanceHistory* history){
	TransferOrder order;
	memcpy(&order, msg->s_payload, sizeof(char) * msg->s_header.s_payload_len);
	
	old_update(state, history, 0, 0, 1, 0);
	
	/* Transfer request */
	if (comm->current_id == order.s_src){
		old_update(state, history, -order.s_amount, msg->s_header.s_local_time, 1, 0);
		old_update(state, history, 0, 0, 1, 0);
		send_transfer_msg(comm, order.s_dst, &order);
		comm->balance -= order.s_amount;
	}
	/* Transfer income */
	else if (comm->current_id == order.s_dst){
		old_update(state, history, order.s_amount, msg->s_header.s_local_time, 1, 1);
		increment_lamport_time();
		send_ack_msg(comm, PARENT_ID);
		comm->balance += order.s_amount;
	}
	else{
		return -1;
	}
	return 0;
}

void old_update(BalanceState* state, BalanceHistory* history, balance_t amount, timestamp_t timestamp_msg, char inc, char fix){
	static timestamp_t prev_time = 0;
    timestamp_t curr_time = get_lamport_time() < timestamp_msg ? timestamp_msg : get_lamport_time();
	timestamp_t i;
	
	if (inc){
		curr_time++;
	}
	set_lamport_time(curr_time);
	if (fix){
		timestamp_msg--;
	}

    history->s_history_len = curr_time + 1;
	
	for (i = prev_time; i < curr_time; i++){
		state->s_time = i;
		history->s_history[i] = *state;
	}
	
	if (amount > 0){
		for (i = timestamp_msg; i < curr_time; i++){
			history->s_history[i].s_balance_pending_in += amount;
		}
	}
	
	prev_time = curr_time;
	state->s_time = curr_time;
	state->s_balance += amount;
	history->s_history[curr_time] = *state;
}

int get_proc_count(int argc, char** argv){
	int proc_count;
	if (!strcmp(argv[1], "-p") && (proc_count = atoi(argv[2])) == (argc - 3)){
		return proc_count;
	}
	return -1;
}

balance_t get_proc_balance(local_id proc_id, char** argv){
	return atoi(argv[proc_id + 2]);
}
