#include "ipc.h"
#include "communication.h"
 
#include <unistd.h>

#define Index(x, id) ((x) < (id) ? (x) : (x) - 1)

int send(void * self, local_id dst, const Message * msg){
	comm* from = (comm*) self;
	
	if (dst == from->current_id){
		return -1;
	}
	if (write(from->pipes[Index(dst, from->current_id) * 2 + 1], msg, sizeof(MessageHeader) + msg->s_header.s_payload_len) < 0){
		return -2;
	}
	return 0;
}

int send_multicast(void * self, const Message * msg){
	comm* from = (comm*) self;
	local_id i;
	
	for (i = 0; i < from->total_ids; i++){
		if (i == from->current_id){
			continue;
		}
		while(send(from, i, msg) < 0);
	}
	return 0;
}

int receive(void * self, local_id from, Message * msg){
	comm* this = (comm*) self;
	
	if (from == this->current_id){
		return -1;
	}
	if (read(this->pipes[Index(from, this->current_id) * 2 + 0], msg, sizeof(MessageHeader)) < (int)sizeof(MessageHeader)){
		return -2;
	}
	
	if (read(this->pipes[Index(from, this->current_id) * 2 + 0], ((char*) msg) + sizeof(MessageHeader), msg->s_header.s_payload_len) < 0){
		return -3;
	}
	return 0;
}

int receive_any(void * self, Message * msg){
	comm* this = (comm*) self;
	local_id i;
	
	for (i = 0; i < this->total_ids; i++){
		if (i == this->current_id){
			continue;
		}
		
		if (!receive(this, i, msg)){
			return 0;
		}
	}
	return -1;
}

