#ifndef __IFMO_DISTRIBUTED_CLASS_COMMUNICATION__H
#define __IFMO_DISTRIBUTED_CLASS_COMMUNICATION__H

#include "ipc.h"
#include "banking.h"

enum PipeTypeOffset 
{
    PIPE_READ_TYPE = 0,
    PIPE_WRITE_TYPE
};

typedef struct pipe_communication{
	int* pipes;
	local_id current_id;
	size_t total_ids;
	balance_t balance;
} comm;

int* pipes_init(size_t proc_count);
comm* comm_init(int* pipes, size_t proc_count, local_id curr_proc, balance_t balance);
void comm_close(comm* comm);

int send_all_proc_event_msg(comm* comm, MessageType type);
void send_all_stop_msg(comm* comm);
void send_transfer_msg(comm* comm, local_id dst, TransferOrder* order);
void send_ack_msg(comm* comm, local_id dst);
void send_balance_history(comm* comm, local_id dst, BalanceHistory* history);

void receive_all_msgs(comm* comm, MessageType type);

#endif

