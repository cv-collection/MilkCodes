#include "ipc.h"

int inc_lamport();
timestamp_t get_lamport_time();
int set_lamport(int val);
